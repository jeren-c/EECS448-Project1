/*
@file Ships.h
*/
#ifndef SHIPS_H
#define SHIPS_H

#include <stdexcept>
#include<iostream>
using namespace std;

class Ships
{

public:
	//set up the ship to unplace - 0 place = 0
	Ships();
	//check if all ships place
	bool isPlace();
	// void decreaseSize(int ship);
	// bool isSunk(int ship);
	bool allSunk();
	// void announce(int ship);

	//if place, set these m_ship = 1
	void setShip1(int num) {m_ship1 = num;}
	void setShip2(int num)  {m_ship2 = num;}
	void setShip3(int num)  {m_ship3 = num;}
	void setShip4(int num)  {m_ship4 = num;}
	void setShip5(int num)  {m_ship5 = num;}

	//get m_ship number
	int getShip1() const{return m_ship1;}
	int getShip2() const{return m_ship2;}
	int getShip3( ) const{return m_ship3;}
	int getShip4( ) const{return m_ship4;}
	int getShip5() const{return m_ship5;}

private:
	  int m_ship1;//1x1
	  int m_ship2;//1x2/
	  int m_ship3;//1x3
	  int m_ship4;//1x4
	  int m_ship5;//1x5
};

#endif
