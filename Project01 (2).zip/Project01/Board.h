/**
* @file Board.h
*/
#ifndef BOARD_H
#define BOARD_H
#include<string>
#include<iostream>

using namespace std;
class Board{
private:
      string** m_board;

public:
    	//create the 9x9 grid
    	Board();

    	//delete the m_board method
    	~Board();

    	//get value from given position method
    	string getEntryAtPosition(int column, int row);

    	//set value to given position method
    	void setEntryAtPosition(string entry, int column, int row);

    	//print Methold
    	void printBoard();

};
#endif
