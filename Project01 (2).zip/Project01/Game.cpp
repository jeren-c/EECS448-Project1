#include "Game.h"

void Game::run()
{
    infoRule();
    Game();
    Players01_place();
    blank();
    Players02_place();
    while (true)
    {
        player01_turn();
        if(players01_ship.allSunk())
        {
            break;
        }
        player02_turn();
        if(players01_ship.allSunk())
        {
            break;
        }
    }
    cout << endl;
    cout << endl;
    cout << "The Game over!\n";
    if(players01_ship.allSunk())
    {
        cout << "====================================\n";
        cout << "congratulations, player2! YOU WON!\n";
        cout << "====================================\n";
    }
    else
    {
        cout << "====================================\n";
        cout << "congratulations, player1! YOU WON!\n";
        cout << "====================================\n";
    }

}


void Game::infoRule()
{
    cout << "Hi,Everyone!\nWelcome to BattleShip Game\n";
    cout << "The Game is between two players!\nBoth players should put their ships on the grid and destroy other player's ship in their gird\n";
    cout << endl;
    cout << "each one have 5 ships, These ship have different size from 1x1 to 1x5\n";
    cout <<"The ship name is called:\nShip1(1x1) Ship2(1x2) Ship3(1x3) Ship4(1x4) Ship5(1x5)\n";
    cout << "Attention: W - water, H - hit and M- miss\n";
    cout << endl;
}

void Game::blank()
{
    cout << "split line -  Avoid player2 see the player1 final grid\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
    cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << " ========================================================\n";
        cout << "split line -  Avoid player2 see the player1 final grid\n";
    cout << "split line -  Avoid player2 see the player1 final grid\n";
}

void Game::AskToInputPosition()
{
    cout << "Which Start position you want to place Ship: \n";
    cout << "Rows: ";
    cin >> p_x;
    while (p_x < 0 || p_x > 8)
    {
        cin >> p_x;
        if(p_x < 0 || p_x > 8)
        {
            cout << "==========================================\n";
            cout << "The Rows out of range!\n";
            cout << "==========================================\n";
        }
    }

    cout << "Cols: ";
    cin >> p_y;
    while (p_y < 0 || p_y > 8)
    {
        cin >> p_y;
        if(p_y < 0 || p_y > 8)
        {
            cout << "==========================================\n";
            cout << "The Cols out of range!\n";
            cout << "==========================================\n";
        }
    }
    cout << "==========================================\n";
}

void Game::AskToInputDirection()
{
    cout << "How to place your ship:\n";
    cout << "1. Go Top\n2. Go Left\n3. Go Down\n4. Go Right\n";
    cout << "Input your choice: ";
    cin >> direction;
    if(direction < 0 || direction > 5)
    {
        throw runtime_error("Please Enter correct choice!\n");
    }
}
//for all of method - player1

void Game::players01_AskShips()
{
    cout << "Here is player1 grid: \n";
    players01.printBoard();
    cout << "choice your ship to place your grid!\n";
    cout << "1. Ship1\n2. Ship2\n3. Ship3\n4. Ship4\n5. Ship5\n";

}

int Game::check_Player01_isHit()
{
    int number = 0;
    if(players02.getEntryAtPosition(target_cols,target_rows) == "5")
    {
        number =  5;//no hit
    }
    else if(players02.getEntryAtPosition(target_cols,target_rows) == "1")
    {
        number =  1;
    }
    else if(players02.getEntryAtPosition(target_cols,target_rows) == "2")
    {
        number =  2;
    }
    else if(players02.getEntryAtPosition(target_cols,target_rows) == "3")
    {
        number =  3;
    }
    else if(players02.getEntryAtPosition(target_cols,target_rows) == "4")
    {
        number =  4;
    }
    else if(players02.getEntryAtPosition(target_cols,target_rows) == "H")
    {
        number = 6;
    }


    return number;
}


void Game::Players01_place()
{

    while(!players01_ship.isPlace())
    {
        try
        {
            players01_AskShips();
            cout << "Input your choice: ";
            cin >> ShipNumber;
            if(ShipNumber < 0 || ShipNumber > 5)
            {
                throw runtime_error("Please Enter correct Ship!\n");
            }
            switch (ShipNumber)
            {
            //Ship1 choice
            case 1:
                if(players01_ship.getShip1() == 0)
                {
                    AskToInputPosition();
                    if(players01.getEntryAtPosition(p_y,p_x) == "W")
                    {
                        players01.setEntryAtPosition("1", p_y,p_x);
                        players01_ship.setShip1(1);
                    }
                    else
                    {
                        throw runtime_error("The other Ship is place here!\n");
                    }
                }
                else
                {
                    cout << endl;
                    cout << "=========================\n";
                    cout << "The ship1 is placed!\n";
                    cout << "=========================\n";
                    cout << endl;
                }
                break;

            //Ship2 choice
            case 2:
                if(players01_ship.getShip2() == 0)
                {
                    AskToInputPosition();
                    AskToInputDirection();
                    switch (direction)
                    {
                    //go top
                    case 1:
                        if(p_x == 0)
                        {
                            throw runtime_error("SHip2 cannot go top in this position!\n");
                        }
                        if(players01.getEntryAtPosition(p_y,p_x) == "W" && players01.getEntryAtPosition(p_y,p_x-1) == "W")
                        {
                            players01.setEntryAtPosition("2", p_y,p_x);
                            players01.setEntryAtPosition("2",p_y,p_x-1);
                            players01_ship.setShip2(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go left
                    case 2:
                        if(p_y == 0)
                        {
                            throw runtime_error("SHip2 cannot go left in this position!\n");
                        }
                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y - 1,p_x) == "W" )
                        {
                            players01.setEntryAtPosition("2", p_y,p_x);
                            players01.setEntryAtPosition("2",p_y - 1,p_x);
                            players01_ship.setShip2(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go down
                    case 3:
                        if(p_x == 9)
                        {
                            throw runtime_error("SHip2 cannot go down in this position!\n");
                        }
                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y ,p_x+1) == "W" )
                        {
                            players01.setEntryAtPosition("2", p_y,p_x);
                            players01.setEntryAtPosition("2",p_y - 1,p_x);
                            players01_ship.setShip2(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }
                        break;
                    //go right
                    case 4:
                        if(p_y == 9)
                        {
                            throw runtime_error("SHip2 cannot go right in this position!\n");
                        }
                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y ,p_x+1) == "W" )
                        {
                            players01.setEntryAtPosition("2", p_y,p_x);
                            players01.setEntryAtPosition("2",p_y + 1,p_x);
                            players01_ship.setShip2(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    }
                }
                else
                {
                    cout << endl;
                    cout << "=========================\n";
                    cout << "The ship2 is placed!\n";
                    cout << "=========================\n";
                    cout << endl;
                }
                break;

            //Ship3 choice
            case 3:
                if(players01_ship.getShip3() == 0)
                {
                    AskToInputPosition();
                    AskToInputDirection();
                    switch (direction)
                    {
                    //go top
                    case 1:
                        if(p_x <= 1)
                        {
                            throw runtime_error("SHip3 cannot go top in this position!\n");
                        }
                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y ,p_x-1) == "W" && players01.getEntryAtPosition(p_y ,p_x-2) == "W" )
                        {
                            players01.setEntryAtPosition("3", p_y,p_x);
                            players01.setEntryAtPosition("3",p_y,p_x-1);
                            players01.setEntryAtPosition("3",p_y,p_x-2);
                            players01_ship.setShip3(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go left
                    case 2:
                        if(p_y <= 1)
                        {
                            throw runtime_error("SHip3 cannot go left in this position!\n");
                        }
                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y -1,p_x) == "W" && players01.getEntryAtPosition(p_y - 2,p_x) == "W" )
                        {
                            players01.setEntryAtPosition("3", p_y,p_x);
                            players01.setEntryAtPosition("3",p_y - 1,p_x);
                            players01.setEntryAtPosition("3",p_y - 2,p_x);
                            players01_ship.setShip3(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go down
                    case 3:
                        if(p_x >= 8)
                        {
                            throw runtime_error("SHip3 cannot go down in this position!\n");
                        }
                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y ,p_x+1) == "W" && players01.getEntryAtPosition(p_y ,p_x+2) == "W" )
                        {
                            players01.setEntryAtPosition("3", p_y,p_x);
                            players01.setEntryAtPosition("3",p_y ,p_x+1);
                            players01.setEntryAtPosition("3",p_y ,p_x+2);
                            players01_ship.setShip3(1);
                            break;
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                    //go right
                    case 4:
                        if(p_y >= 8)
                        {
                            throw runtime_error("SHip3 cannot go right in this position!\n");
                        }

                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y +1,p_x) == "W" && players01.getEntryAtPosition(p_y +2,p_x) == "W" )
                        {
                            players01.setEntryAtPosition("3", p_y,p_x);
                            players01.setEntryAtPosition("3",p_y+1 ,p_x);
                            players01.setEntryAtPosition("3",p_y+2 ,p_x);
                            players01_ship.setShip3(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    }
                }
                else
                {
                    cout << endl;
                    cout << "=========================\n";
                    cout << "The ship3 is placed!\n";
                    cout << "=========================\n";
                    cout << endl;
                }
                break;

            case 4:
                if(players01_ship.getShip4() == 0)
                {
                    AskToInputPosition();
                    AskToInputDirection();
                    switch (direction)
                    {
                    //go top
                    case 1:
                        if(p_x <= 2)
                        {
                            throw runtime_error("SHip 4cannot go top in this position!\n");
                        }
                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y ,p_x-1) == "W" && players01.getEntryAtPosition(p_y ,p_x-2) == "W" && players01.getEntryAtPosition(p_y ,p_x-3) == "W" )
                        {
                            players01.setEntryAtPosition("4", p_y,p_x);
                            players01.setEntryAtPosition("4",p_y,p_x-1);
                            players01.setEntryAtPosition("4",p_y,p_x-2);
                            players01.setEntryAtPosition("4",p_y,p_x-3);
                            players01_ship.setShip4(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }
                        break;
                    //go left
                    case 2:
                        if(p_y <= 2)
                        {
                            throw runtime_error("SHip4 cannot go left in this position!\n");
                        }

                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y - 1,p_x) == "W" && players01.getEntryAtPosition(p_y  - 2,p_x) == "W" && players01.getEntryAtPosition(p_y  - 3,p_x) == "W")
                        {
                            players01.setEntryAtPosition("4", p_y,p_x);
                            players01.setEntryAtPosition("4",p_y - 1,p_x);
                            players01.setEntryAtPosition("4",p_y - 2,p_x);
                            players01.setEntryAtPosition("4",p_y - 3,p_x);
                            players01_ship.setShip4(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go down
                    case 3:
                        if(p_x >= 7)
                        {
                            throw runtime_error("SHip4 cannot go down in this position!\n");
                        }
                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y ,p_x+1) == "W" && players01.getEntryAtPosition(p_y ,p_x+2) == "W" && players01.getEntryAtPosition(p_y ,p_x+3) == "W" )
                        {
                            players01.setEntryAtPosition("4", p_y,p_x);
                            players01.setEntryAtPosition("4",p_y ,p_x+1);
                            players01.setEntryAtPosition("4",p_y ,p_x+2);
                            players01.setEntryAtPosition("4",p_y ,p_x+3);
                            players01_ship.setShip4(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go right
                    case 4:
                        if(p_y >= 7)
                        {
                            throw runtime_error("SHip4 cannot go right in this position!\n");
                        }
                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y +1,p_x) == "W" && players01.getEntryAtPosition(p_y +2,p_x) == "W" && players01.getEntryAtPosition(p_y +3,p_x) == "W" )
                        {
                            players01.setEntryAtPosition("4", p_y,p_x);
                            players01.setEntryAtPosition("4",p_y+1 ,p_x);
                            players01.setEntryAtPosition("4",p_y+2 ,p_x);
                            players01.setEntryAtPosition("4",p_y+3 ,p_x);
                            players01_ship.setShip4(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    }
                }
                else
                {
                    cout << endl;
                    cout << "=========================\n";
                    cout << "The ship4 is placed!\n";
                    cout << "=========================\n";
                    cout << endl;
                }
                break;

            case 5:
                if(players01_ship.getShip5() == 0)
                {
                    AskToInputPosition();
                    AskToInputDirection();
                    switch (direction)
                    {
                    //go top
                    case 1:
                        if(p_x <= 3)
                        {
                            throw runtime_error("SHip 5 cannot go top in this position!\n");
                        }
                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y ,p_x-1) == "W" && players01.getEntryAtPosition(p_y ,p_x-2) == "W" && players01.getEntryAtPosition(p_y ,p_x-3) == "W" && players01.getEntryAtPosition(p_y ,p_x-4) == "W"  )
                        {
                            players01.setEntryAtPosition("5", p_y,p_x);
                            players01.setEntryAtPosition("5",p_y,p_x-1);
                            players01.setEntryAtPosition("5",p_y,p_x-2);
                            players01.setEntryAtPosition("5",p_y,p_x-3);
                            players01.setEntryAtPosition("5",p_y,p_x-4);
                            players01_ship.setShip5(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go left
                    case 2:
                        if(p_y <= 2)
                        {
                            throw runtime_error("SHip4 cannot go left in this position!\n");
                        }

                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y -1,p_x) == "W" && players01.getEntryAtPosition(p_y -2,p_x) == "W" && players01.getEntryAtPosition(p_y -3,p_x) == "W" && players01.getEntryAtPosition(p_y -4,p_x) == "W")
                        {
                            players01.setEntryAtPosition("5", p_y,p_x);
                            players01.setEntryAtPosition("5",p_y - 1,p_x);
                            players01.setEntryAtPosition("5",p_y - 2,p_x);
                            players01.setEntryAtPosition("5",p_y - 3,p_x);
                            players01.setEntryAtPosition("5",p_y - 4,p_x);
                            players01_ship.setShip5(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }


                        break;
                    //go down
                    case 3:
                        if(p_x >= 7)
                        {
                            throw runtime_error("SHip5 cannot go down in this position!\n");
                        }
                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y ,p_x+1) == "W" && players01.getEntryAtPosition(p_y ,p_x+2) == "W" && players01.getEntryAtPosition(p_y ,p_x+3) == "W" && players01.getEntryAtPosition(p_y ,p_x+4) == "W"  )
                        {
                            players01.setEntryAtPosition("5", p_y,p_x);
                            players01.setEntryAtPosition("5",p_y ,p_x+1);
                            players01.setEntryAtPosition("5",p_y ,p_x+2);
                            players01.setEntryAtPosition("5",p_y ,p_x+3);
                            players01.setEntryAtPosition("5",p_y ,p_x+4);
                            players01_ship.setShip5(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }
                        break;
                    //go right
                    case 4:
                        if(p_y >= 7)
                        {
                            throw runtime_error("SHip5 cannot go right in this position!\n");
                        }

                        if(players01.getEntryAtPosition( p_y,p_x) == "W" && players01.getEntryAtPosition(p_y +1,p_x) == "W" && players01.getEntryAtPosition(p_y +2,p_x) == "W" && players01.getEntryAtPosition(p_y +3,p_x) == "W" && players01.getEntryAtPosition(p_y +4,p_x) == "W")
                        {
                            players01.setEntryAtPosition("5", p_y,p_x);
                            players01.setEntryAtPosition("5",p_y+1 ,p_x);
                            players01.setEntryAtPosition("5",p_y+2 ,p_x);
                            players01.setEntryAtPosition("5",p_y+3 ,p_x);
                            players01.setEntryAtPosition("5",p_y+4 ,p_x);
                            players01_ship.setShip5(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }


                    }
                }
                else
                {
                    cout << endl;
                    cout << "=========================\n";
                    cout << "The ship5 is placed!\n";
                    cout << "=========================\n";
                    cout << endl;
                }
                break;
            }//First switch
        }
        catch(runtime_error& e)
        {
            cout << endl;
            cout << "=========================\n";
            cout << e.what();
            cout << "=========================\n";
            cout << endl;
        }
    }//while loop

    cout << "The player1's final Grid is:\n";
    players01.printBoard();
}

void Game::player01_hit_choice()
{
    cout << endl;
    cout << "Players1 turn!\n";
    cout << "-------------------------------------------------\n";
    cout << "below is player2 grid:\n";
    players02_empty_board.printBoard();
    cout << "which position you want to hit: \n";
    cout << "Enter rows number: ";
    cin >> target_rows;
    while (target_rows > 8 || target_rows < 0)
    {
        cin >> target_rows;
        if(target_rows > 8 || target_rows < 0)
        {
            cout << "The rows is out of range!\n";
            cout << "Please enter a correct rows: ";
        }
    }

    cout << "Enter cols number: ";
    cin >> target_cols;
    while (target_cols > 8 || target_cols < 0)
    {
        cin >> target_cols;
        if(target_cols > 8 || target_cols < 0)
        {
            cout << "The cols is out of range!\n";
            cout << "Please enter a correct cols: ";
        }
    }
    cout << "-----------------------------------------------------------\n";
    cout << endl;
    cout << "The Status:\n";
}

void Game::player01_turn()
{
    player01_hit_choice();
    int Status = check_Player01_isHit();
    switch (Status)
    {
    case 0:
        players02_empty_board.setEntryAtPosition("M" ,target_cols,target_rows);
        cout << "=======================================\n";
        cout << "YOU MISS!\n";
        cout << "=======================================\n";
        break;
    case 1:
        players02.setEntryAtPosition("H" ,target_cols,target_rows);
        players02_empty_board.setEntryAtPosition("H" ,target_cols,target_rows);
        players02_ship.setShip1(0);
        cout << "=============================================\n";
        cout << "The player2' ship1 is destroy!\n";
        cout << "=============================================\n";

        break;
    case 2:

        players02.setEntryAtPosition("H" ,target_cols,target_rows);
        players02_empty_board.setEntryAtPosition("H" ,target_cols,target_rows);
        count2++;
        if(count2 == Ship2_length )
        {
            players02_ship.setShip2(0);
            cout << "=============================================\n";
            cout << "The player2' ship2 is destroy!\n";
            cout << "=============================================\n";
        }
        else
        {
            cout << "=============================================\n";
            cout << "Good Hit!\n";
            cout << "=============================================\n";
        }
        break;

    case 3:

        players02.setEntryAtPosition("H" ,target_cols,target_rows);
        players02_empty_board.setEntryAtPosition("H" ,target_cols,target_rows);
        count3++;
        if( count3 == Ship3_length )
        {
            players02_ship.setShip3(0);
            cout << "=============================================\n";
            cout << "The player2' ship3 is destroy!\n";
            cout << "=============================================\n";
        }
        else
        {
            cout << "=============================================\n";
            cout << "Good Hit!\n";
            cout << "=============================================\n";
        }
        break;
    case 4:
        players02.setEntryAtPosition("H" ,target_cols,target_rows);
        players02_empty_board.setEntryAtPosition("H" ,target_cols,target_rows);
        count4++;
        if( count4 == Ship4_length )
        {
            players02_ship.setShip4(0);
            cout << "=============================================\n";
            cout << "The player2' ship4 is destroy!\n";
            cout << "=============================================\n";
        }
        else
        {
            cout << "=============================================\n";
            cout << "Good Hit!\n";
            cout << "=============================================\n";
        }
        break;
    case 5:
        players02.setEntryAtPosition("H" ,target_cols,target_rows);
        players02_empty_board.setEntryAtPosition("H" ,target_cols,target_rows);
        count5++;
        if(  count5 == Ship5_length )
        {
            players02_ship.setShip5(0);
            cout << "=============================================\n";
            cout << "The player2' ship5 is destroy!\n";
            cout << "=============================================\n";

        }
        else
        {
            cout << "=============================================\n";
            cout << "Good Hit!\n";
            cout << "=============================================\n";
        }
        break;
    case 6:
            cout << "=======================================\n";
            cout << "The place you hit ag!\n";
            cout << "=======================================\n";
            break;
    }

}

//for all of method - player2
void Game::Players02_place()
{

    while(!players02_ship.isPlace())
    {
        try
        {
            players02_AskShips();
            cout << "Input your choice: ";
            cin >> ShipNumber;
            if(ShipNumber < 0 || ShipNumber > 5)
            {
                throw runtime_error("Please Enter correct Ship!\n");
            }
            switch (ShipNumber)
            {
            //Ship1 choice
            case 1:
                if(players02_ship.getShip1() == 0)
                {
                    AskToInputPosition();
                    if(players02.getEntryAtPosition(p_y,p_x) == "W")
                    {
                        players02.setEntryAtPosition("1", p_y,p_x);
                        players02_ship.setShip1(1);
                    }
                    else
                    {
                        throw runtime_error("The other Ship is place here!\n");
                    }
                }
                else
                {
                    cout << endl;
                    cout << "=========================\n";
                    cout << "The ship1 is placed!\n";
                    cout << "=========================\n";
                    cout << endl;
                }
                break;

            //Ship2 choice
            case 2:
                if(players02_ship.getShip2() == 0)
                {
                    AskToInputPosition();
                    AskToInputDirection();
                    switch (direction)
                    {
                    //go top
                    case 1:
                        if(p_x == 0)
                        {
                            throw runtime_error("SHip2 cannot go top in this position!\n");
                        }
                        if(players02.getEntryAtPosition(p_y,p_x) == "W" && players02.getEntryAtPosition(p_y,p_x-1) == "W")
                        {
                            players02.setEntryAtPosition("2", p_y,p_x);
                            players02.setEntryAtPosition("2",p_y,p_x-1);
                            players02_ship.setShip2(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go left
                    case 2:
                        if(p_y == 0)
                        {
                            throw runtime_error("SHip2 cannot go left in this position!\n");
                        }
                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y - 1,p_x) == "W" )
                        {
                            players02.setEntryAtPosition("2", p_y,p_x);
                            players02.setEntryAtPosition("2",p_y - 1,p_x);
                            players02_ship.setShip2(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go down
                    case 3:
                        if(p_x == 9)
                        {
                            throw runtime_error("SHip2 cannot go down in this position!\n");
                        }
                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y ,p_x+1) == "W" )
                        {
                            players02.setEntryAtPosition("2", p_y,p_x);
                            players02.setEntryAtPosition("2",p_y - 1,p_x);
                            players02_ship.setShip2(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }
                        break;
                    //go right
                    case 4:
                        if(p_y == 9)
                        {
                            throw runtime_error("SHip2 cannot go right in this position!\n");
                        }
                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y ,p_x+1) == "W" )
                        {
                            players02.setEntryAtPosition("2", p_y,p_x);
                            players02.setEntryAtPosition("2",p_y + 1,p_x);
                            players02_ship.setShip2(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    }
                }
                else
                {
                    cout << endl;
                    cout << "=========================\n";
                    cout << "The ship2 is placed!\n";
                    cout << "=========================\n";
                    cout << endl;
                }
                break;

            //Ship3 choice
            case 3:
                if(players02_ship.getShip3() == 0)
                {
                    AskToInputPosition();
                    AskToInputDirection();
                    switch (direction)
                    {
                    //go top
                    case 1:
                        if(p_x <= 1)
                        {
                            throw runtime_error("SHip3 cannot go top in this position!\n");
                        }
                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y ,p_x-1) == "W" && players02.getEntryAtPosition(p_y ,p_x-2) == "W" )
                        {
                            players02.setEntryAtPosition("3", p_y,p_x);
                            players02.setEntryAtPosition("3",p_y,p_x-1);
                            players02.setEntryAtPosition("3",p_y,p_x-2);
                            players02_ship.setShip3(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go left
                    case 2:
                        if(p_y <= 1)
                        {
                            throw runtime_error("SHip3 cannot go left in this position!\n");
                        }
                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y -1,p_x) == "W" && players02.getEntryAtPosition(p_y - 2,p_x) == "W" )
                        {
                            players02.setEntryAtPosition("3", p_y,p_x);
                            players02.setEntryAtPosition("3",p_y - 1,p_x);
                            players02.setEntryAtPosition("3",p_y - 2,p_x);
                            players02_ship.setShip3(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go down
                    case 3:
                        if(p_x >= 8)
                        {
                            throw runtime_error("SHip3 cannot go down in this position!\n");
                        }
                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y ,p_x+1) == "W" && players02.getEntryAtPosition(p_y ,p_x+2) == "W" )
                        {
                            players02.setEntryAtPosition("3", p_y,p_x);
                            players02.setEntryAtPosition("3",p_y ,p_x+1);
                            players02.setEntryAtPosition("3",p_y ,p_x+2);
                            players02_ship.setShip3(1);
                            break;
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                    //go right
                    case 4:
                        if(p_y >= 8)
                        {
                            throw runtime_error("SHip3 cannot go right in this position!\n");
                        }

                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y +1,p_x) == "W" && players02.getEntryAtPosition(p_y +2,p_x) == "W" )
                        {
                            players02.setEntryAtPosition("3", p_y,p_x);
                            players02.setEntryAtPosition("3",p_y+1 ,p_x);
                            players02.setEntryAtPosition("3",p_y+2 ,p_x);
                            players02_ship.setShip3(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    }
                }
                else
                {
                    cout << endl;
                    cout << "=========================\n";
                    cout << "The ship3 is placed!\n";
                    cout << "=========================\n";
                    cout << endl;
                }
                break;

            case 4:
                if(players02_ship.getShip4() == 0)
                {
                    AskToInputPosition();
                    AskToInputDirection();
                    switch (direction)
                    {
                    //go top
                    case 1:
                        if(p_x <= 2)
                        {
                            throw runtime_error("SHip 4cannot go top in this position!\n");
                        }
                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y ,p_x-1) == "W" && players02.getEntryAtPosition(p_y ,p_x-2) == "W" && players02.getEntryAtPosition(p_y ,p_x-3) == "W" )
                        {
                            players02.setEntryAtPosition("4", p_y,p_x);
                            players02.setEntryAtPosition("4",p_y,p_x-1);
                            players02.setEntryAtPosition("4",p_y,p_x-2);
                            players02.setEntryAtPosition("4",p_y,p_x-3);
                            players02_ship.setShip4(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }
                        break;
                    //go left
                    case 2:
                        if(p_y <= 2)
                        {
                            throw runtime_error("SHip4 cannot go left in this position!\n");
                        }

                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y - 1,p_x) == "W" && players02.getEntryAtPosition(p_y  - 2,p_x) == "W" && players02.getEntryAtPosition(p_y  - 3,p_x) == "W")
                        {
                            players02.setEntryAtPosition("4", p_y,p_x);
                            players02.setEntryAtPosition("4",p_y - 1,p_x);
                            players02.setEntryAtPosition("4",p_y - 2,p_x);
                            players02.setEntryAtPosition("4",p_y - 3,p_x);
                            players02_ship.setShip4(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go down
                    case 3:
                        if(p_x >= 7)
                        {
                            throw runtime_error("SHip4 cannot go down in this position!\n");
                        }
                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y ,p_x+1) == "W" && players02.getEntryAtPosition(p_y ,p_x+2) == "W" && players02.getEntryAtPosition(p_y ,p_x+3) == "W" )
                        {
                            players02.setEntryAtPosition("4", p_y,p_x);
                            players02.setEntryAtPosition("4",p_y ,p_x+1);
                            players02.setEntryAtPosition("4",p_y ,p_x+2);
                            players02.setEntryAtPosition("4",p_y ,p_x+3);
                            players02_ship.setShip4(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go right
                    case 4:
                        if(p_y >= 7)
                        {
                            throw runtime_error("SHip4 cannot go right in this position!\n");
                        }
                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y +1,p_x) == "W" && players02.getEntryAtPosition(p_y +2,p_x) == "W" && players02.getEntryAtPosition(p_y +3,p_x) == "W" )
                        {
                            players02.setEntryAtPosition("4", p_y,p_x);
                            players02.setEntryAtPosition("4",p_y+1 ,p_x);
                            players02.setEntryAtPosition("4",p_y+2 ,p_x);
                            players02.setEntryAtPosition("4",p_y+3 ,p_x);
                            players02_ship.setShip4(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    }
                }
                else
                {
                    cout << endl;
                    cout << "=========================\n";
                    cout << "The ship4 is placed!\n";
                    cout << "=========================\n";
                    cout << endl;
                }
                break;

            case 5:
                if(players02_ship.getShip5() == 0)
                {
                    AskToInputPosition();
                    AskToInputDirection();
                    switch (direction)
                    {
                    //go top
                    case 1:
                        if(p_x <= 3)
                        {
                            throw runtime_error("SHip 5 cannot go top in this position!\n");
                        }
                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y ,p_x-1) == "W" && players02.getEntryAtPosition(p_y ,p_x-2) == "W" && players02.getEntryAtPosition(p_y ,p_x-3) == "W" && players02.getEntryAtPosition(p_y ,p_x-4) == "W"  )
                        {
                            players02.setEntryAtPosition("5", p_y,p_x);
                            players02.setEntryAtPosition("5",p_y,p_x-1);
                            players02.setEntryAtPosition("5",p_y,p_x-2);
                            players02.setEntryAtPosition("5",p_y,p_x-3);
                            players02.setEntryAtPosition("5",p_y,p_x-4);
                            players02_ship.setShip5(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }

                        break;
                    //go left
                    case 2:
                        if(p_y <= 2)
                        {
                            throw runtime_error("SHip4 cannot go left in this position!\n");
                        }

                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y -1,p_x) == "W" && players02.getEntryAtPosition(p_y -2,p_x) == "W" && players02.getEntryAtPosition(p_y -3,p_x) == "W" && players02.getEntryAtPosition(p_y -4,p_x) == "W")
                        {
                            players02.setEntryAtPosition("5", p_y,p_x);
                            players02.setEntryAtPosition("5",p_y - 1,p_x);
                            players02.setEntryAtPosition("5",p_y - 2,p_x);
                            players02.setEntryAtPosition("5",p_y - 3,p_x);
                            players02.setEntryAtPosition("5",p_y - 4,p_x);
                            players02_ship.setShip5(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }


                        break;
                    //go down
                    case 3:
                        if(p_x >= 7)
                        {
                            throw runtime_error("SHip5 cannot go down in this position!\n");
                        }
                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y ,p_x+1) == "W" && players02.getEntryAtPosition(p_y ,p_x+2) == "W" && players02.getEntryAtPosition(p_y ,p_x+3) == "W" && players02.getEntryAtPosition(p_y ,p_x+4) == "W"  )
                        {
                            players02.setEntryAtPosition("5", p_y,p_x);
                            players02.setEntryAtPosition("5",p_y ,p_x+1);
                            players02.setEntryAtPosition("5",p_y ,p_x+2);
                            players02.setEntryAtPosition("5",p_y ,p_x+3);
                            players02.setEntryAtPosition("5",p_y ,p_x+4);
                            players02_ship.setShip5(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }
                        break;
                    //go right
                    case 4:
                        if(p_y >= 7)
                        {
                            throw runtime_error("SHip5 cannot go right in this position!\n");
                        }

                        if(players02.getEntryAtPosition( p_y,p_x) == "W" && players02.getEntryAtPosition(p_y +1,p_x) == "W" && players02.getEntryAtPosition(p_y +2,p_x) == "W" && players02.getEntryAtPosition(p_y +3,p_x) == "W" && players02.getEntryAtPosition(p_y +4,p_x) == "W")
                        {
                            players02.setEntryAtPosition("5", p_y,p_x);
                            players02.setEntryAtPosition("5",p_y+1 ,p_x);
                            players02.setEntryAtPosition("5",p_y+2 ,p_x);
                            players02.setEntryAtPosition("5",p_y+3 ,p_x);
                            players02.setEntryAtPosition("5",p_y+4 ,p_x);
                            players02_ship.setShip5(1);
                        }
                        else
                        {
                            throw runtime_error("The other Ship is place here!\n");
                        }


                    }
                }
                else
                {
                    cout << endl;
                    cout << "=========================\n";
                    cout << "The ship5 is placed!\n";
                    cout << "=========================\n";
                    cout << endl;
                }
                break;
            }//First switch
        }
        catch(runtime_error& e)
        {
            cout << endl;
            cout << "=========================\n";
            cout << e.what();
            cout << "=========================\n";
            cout << endl;
        }
    }//while loop

    cout << "==========================================\n";
    cout << "The player1's final Grid is:\n";
    players02.printBoard();
    cout << "==========================================\n";
}

void Game::players02_AskShips()
{
    cout << "==========================================\n";
    cout << "Here is player2 grid: \n";
    players02.printBoard();
    cout << "choice your ship to place your grid!\n";
    cout << "1. Ship1\n2. Ship2\n3. Ship3\n4. Ship4\n5. Ship5\n";

}

int Game::check_Player02_isHit()
{
    int number = 0;
    if(players01.getEntryAtPosition(target_cols,target_rows) == "5")
    {
        number =  5;//no hit
    }
    else if(players01.getEntryAtPosition(target_cols,target_rows) == "1")
    {
        number =  1;
    }
    else if(players01.getEntryAtPosition(target_cols,target_rows) == "2")
    {
        number =  2;
    }
    else if(players01.getEntryAtPosition(target_cols,target_rows) == "3")
    {
        number =  3;
    }
    else if(players01.getEntryAtPosition(target_cols,target_rows) == "4")
    {
        number =  4;
    }

        else if(players01.getEntryAtPosition(target_cols,target_rows) == "H")
        {
            number =  6;
        }
    return number;
}


void Game::player02_turn()
{
    player02_hit_choice();
    int Status = check_Player02_isHit();
    switch (Status)
    {
    case 0:
        players01_empty_board.setEntryAtPosition("M" ,target_cols,target_rows);
        cout << "=======================================\n";
        cout << "YOU MISS!\n";
        cout << "=======================================\n";
        break;
    case 1:
        players01.setEntryAtPosition("H" ,target_cols,target_rows);
        players01_empty_board.setEntryAtPosition("H" ,target_cols,target_rows);
        players01_ship.setShip1(0);
        cout << "=============================================\n";
        cout << "The player1' ship1 is destroy!\n";
        cout << "=============================================\n";

        break;
    case 2:

        players01.setEntryAtPosition("H" ,target_cols,target_rows);
        players01_empty_board.setEntryAtPosition("H" ,target_cols,target_rows);
        count2_player2++;
        if(count2_player2 == Ship2_length )
        {
            players01_ship.setShip2(0);
            cout << "=============================================\n";
            cout << "The player1' ship2 is destroy!\n";
            cout << "=============================================\n";
        }
        else
        {
            cout << "=============================================\n";
            cout << "Good Hit!\n";
            cout << "=============================================\n";
        }
        break;

    case 3:

        players01.setEntryAtPosition("H" ,target_cols,target_rows);
        players01_empty_board.setEntryAtPosition("H" ,target_cols,target_rows);
        count3_player2++;
        if( count3_player2 == Ship3_length )
        {
            players01_ship.setShip3(0);
            cout << "=============================================\n";
            cout << "The player1' ship3 is destroy!\n";
            cout << "=============================================\n";
        }
        else
        {
            cout << "=============================================\n";
            cout << "Good Hit!\n";
            cout << "=============================================\n";
        }
        break;
    case 4:
        players01.setEntryAtPosition("H" ,target_cols,target_rows);
        players01_empty_board.setEntryAtPosition("H" ,target_cols,target_rows);
        count4_player2++;
        if( count4_player2 == Ship4_length )
        {
            players01_ship.setShip4(0);
            cout << "=============================================\n";
            cout << "The player1' ship4 is destroy!\n";
            cout << "=============================================\n";
        }
        else
        {
            cout << "=============================================\n";
            cout << "Good Hit!\n";
            cout << "=============================================\n";
        }
        break;
    case 5:
        players01.setEntryAtPosition("H" ,target_cols,target_rows);
        players01_empty_board.setEntryAtPosition("H" ,target_cols,target_rows);
        count5_player2++;
        if(  count5_player2 == Ship5_length )
        {
            players01_ship.setShip5(0);
            cout << "=============================================\n";
            cout << "The player1' ship5 is destroy!\n";
            cout << "=============================================\n";

        }
        else
        {
            cout << "=============================================\n";
            cout << "Good Hit!\n";
            cout << "=============================================\n";
        }
        break;

    case 6:
                cout << "=======================================\n";
                cout << "The place you hit again!\n";
                cout << "=======================================\n";
                break;

    }
}

void Game::player02_hit_choice()
{
    cout << endl;
    cout << "Players2 turn!\n";
    cout << "-------------------------------------------------\n";
    cout << "below is player1 grid:\n";
    players01_empty_board.printBoard();
    cout << "which position you want to hit: \n";
    cout << "Enter rows number: ";
    cin >> target_rows;
    while (target_rows > 8 || target_rows < 0)
    {
        cin >> target_rows;
        if(target_rows > 8 || target_rows < 0)
        {
            cout << "The rows is out of range!\n";
            cout << "Please enter a correct rows: ";
        }
    }

    cout << "Enter cols number: ";
    cin >> target_cols;
    while (target_cols > 8 || target_cols < 0)
    {
        cin >> target_cols;
        if(target_cols > 8 || target_cols < 0)
        {
            cout << "The cols is out of range!\n";
            cout << "Please enter a correct cols: ";
        }
    }
    cout << "-----------------------------------------------------------\n";
    cout << endl;
    cout << "The Status:\n";
}
