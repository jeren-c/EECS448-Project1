//Game.h

#ifndef GAME_H
#define GAME_H
#include "Ships.h"
#include "Board.h"
#include <string>
#include <iostream>
using namespace std;

class Game{
private:
    Board players01 = Board();
    Board players02 = Board();
    Ships players01_ship = Ships();
    Ships players02_ship = Ships();
    Board players01_empty_board = Board();
    Board players02_empty_board = Board();





    const int Ship2_length = 2;
    const int Ship3_length = 3;
    const int Ship4_length = 4;
    const int Ship5_length = 5;
    int count2 = 0;
    int count3 = 0;
    int count4 = 0;
    int count5 = 0;

        int count2_player2 = 0;
        int count3_player2 = 0;
        int count4_player2 = 0;
        int count5_player2 = 0;



    int ShipNumber = 0;
    int direction = 0;
    int p_x  = 0;
    int p_y = 0;
    int target_rows = 0;
    int target_cols = 0;

    bool checkShip2Destroy = false;
public:
    //init the game
    Game(){}

    //deconstrutor
    ~Game(){}

    //run the game
    void run();


    //helper method
    void infoRule();
    void printPlayerBoards();
    void AskToInputPosition();
    void AskToInputDirection();
    void blank();





    //All of method for player01
    void Players01_place();
    void players01_AskShips();
    void player01_hit_choice();
    int check_Player01_isHit();
    void player01_turn();

    //all of method for players02
    void Players02_place();
    void players02_AskShips();
    int check_Player02_isHit();
    void player02_turn();
    void player02_hit_choice();


};
#endif
