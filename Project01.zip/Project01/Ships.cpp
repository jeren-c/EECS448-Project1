#include "Ships.h"

Ships::Ships(){
		m_ship1=0;//initialize ship variables in case they are not assigned a value below
		m_ship2=0;
		m_ship3=0;
		m_ship4=0;
		m_ship5=0;
}

bool Ships::isPlace()
{
		if(m_ship1==0 || m_ship2==0 || m_ship3 == 0||m_ship4 == 0||m_ship5 ==0 )
		{
			return false;
		}
		return true;
}

bool Ships::allSunk()
{
		if(m_ship5 != 0 || m_ship1 != 0 || m_ship2 != 0 || m_ship3 != 0 || m_ship4 != 0)
		{
			return false;
		}
		return true;
}
