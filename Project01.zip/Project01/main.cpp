/*

@file main.cpp
*/
#include"Board.h"
#include "Game.h"
#include <iostream>
#include <string>

int main ()
{
	Game newGame;
	newGame.run();


}
