/*
@file Board.cpp
*/
#include "Board.h"
Board::Board(){
  m_board = new string*[9];
  for(int i=0;i<9;i++){
    m_board[i] = new string[9];
    for(int j=0;j<9;j++){
      m_board[i][j] = "W"; // W mean that position is water;
    }
  }
}

Board::~Board(){
  for(int i=0;i<9;i++){
    delete[] m_board[i];
  }
  delete[] m_board;
}

string Board::getEntryAtPosition(int column, int row){
  return(m_board[row][column]);
}

void Board::setEntryAtPosition(string entry, int column, int row){
  m_board[row][column] = entry;
}



void Board::printBoard(){
    for (int i = 0; i < 9; i++)
    {
        for (int j = 0; j < 9; j++)
        {
            cout << m_board[i][j] << " ";
        }
        cout << endl;
    }
}
